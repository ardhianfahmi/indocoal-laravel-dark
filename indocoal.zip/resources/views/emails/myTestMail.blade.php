<!DOCTYPE html>
<html>

<head>
    <title>Indocoal Visitor</title>
</head>

<body>
    <h1>{{ $details['name'] }}</h1>
    <h3>Subject : {{ $details['title'] }}</h3>
    <p><?php echo $details['body']; ?></p>

    <p>Thank you</p>
</body>

</html>
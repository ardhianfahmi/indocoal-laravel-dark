<!-- Vendor JS Files -->
<script src="<?php echo e(('/vendor/purecounter/purecounter.js')); ?>"></script>
<script src="<?php echo e(('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(('/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(('/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(('/vendor/php-email-form/validate.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(('/js/main.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\indocoal-laravel\resources\views/layout/script-foot.blade.php ENDPATH**/ ?>